$(function() {
	$('.category-list>li').on('click', function() {
		let key = $(this).text();
		let data = {
				key: key
		}
		$.ajax({
    			url: 'SearchAction',
    			method: 'get',
    			data: data,
    			dataType: 'json',
    			success: function() {
    				location.href='./Search.jsp';
    			},
    			error: function() {
    				alert('服务器错误！');
    			}
    		})
	})
})