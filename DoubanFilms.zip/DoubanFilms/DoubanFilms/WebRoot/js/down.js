$(function () {  
    if ($('.person-info').text() != '登录') {
        $('.person-info').on('click', function (event) {  
            event.preventDefault();
            $('.person-list').toggle();
        })
    }
})