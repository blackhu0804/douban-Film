$(function () {  
	Date.prototype.Format = function (fmt) {
        var o = {
            "y+": this.getFullYear(),
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S+": this.getMilliseconds() //毫秒
        };
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                if (k == "y+") {
                    fmt = fmt.replace(RegExp.$1, ("" + o[k]).substr(4 - RegExp.$1.length));
                } else if (k == "S+") {
                    var lens = RegExp.$1.length;
                    lens = lens == 1 ? 3 : lens;
                    fmt = fmt.replace(RegExp.$1, ("00" + o[k]).substr(("" + o[k]).length - 1, lens));
                } else {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
        }
        return fmt;
    }

    $('.submit-comment').on('click', function () {  
    	let rank = $('.flim-id').text()
        let detail = $('.w-e-text').html()
        let approve_num = $('#star-score').val()
        let username = $('.person-info').text()
        let date = new Date();
        date = date.Format('yyyy-MM-dd hh:mm:ss')
        let coms = {
        	"rank": rank,
            "coms.detail": detail,
            "score": approve_num,
        }
        let starTpl = ''
        for(var i = 0;i < approve_num; i++) {
            starTpl += `<img src="./img/star-on.png">`
        }
        
        if(approve_num == '') {
        	alert('请为该电影打分！')
    	} else if (detail == '') {
    		alert('请输入评论内容')
    	} else {
    		$.ajax({
                url: 'CommentAction',
                type: 'post',
                data: coms,
                dataType: 'json',
                success: function (res) { 
                	console.log(res)
                	if(res == '{"success"}') {
                		$('.hots-comments').append(`
                                <div class="comment-item">
                                    <p class="comment-info">
                                        ${detail}
                                    </p>
                                    <p class="comment-person">
                                        ${starTpl}
                                        ${username}  
                                        <span class="time">
                                            ${date}
                                        </span>
                                    </p>
                                </div>
                            `)
                            $('.w-e-text').html('');
                	} else {
                		alert('请登录！')
                		location.href = './login.jsp'
                	}
                	
                },
                error: function (err) { 
                    alert('服务器异常!')
                }
            })
    	}
        
    })
})