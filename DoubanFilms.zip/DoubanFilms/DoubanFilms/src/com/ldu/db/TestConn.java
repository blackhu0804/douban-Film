//package com.ldu.db;
//
//import java.util.Iterator;
//import java.util.List;
//
//import org.hibernate.Criteria;
//import org.hibernate.Session;
//import org.hibernate.Transaction;
//import org.hibernate.criterion.MatchMode;
//import org.hibernate.criterion.Restrictions;
//
//import com.ldu.getsession.HibernateSessionFactory;
//import com.ldu.model.Movies;
//
//public class TestConn {
//
//	public static void main(String[] args) {
//		Session session = HibernateSessionFactory.getSession();
//		Transaction tx = null;
//		
//		Criteria cr = session.createCriteria(Movies.class);
//		String sql="from users";
//		String key="����";
//		List list;
//		
//		cr.add(Restrictions.ilike("category", "%"+key+"%" ,MatchMode.ANYWHERE));
//		list=cr.list();
//		
//		
//		System.out.println("������С��"+list.size());
//		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
//			Movies movies=(Movies) iterator.next();
//			System.out.println(movies.getName());
//		}
//		
//		System.out.println("jieshu");
//	}
//
//}
