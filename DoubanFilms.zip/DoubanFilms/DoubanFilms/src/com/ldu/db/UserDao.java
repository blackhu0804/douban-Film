package com.ldu.db;

import javax.xml.registry.infomodel.User;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.List; 
import com.ldu.model.*;
import com.ldu.getsession.*;

public class UserDao {
	/** 
     * �� 
     * @param user 
     */  
    public void add(User user){  
        Session session=HibernateSessionFactory.getSession();
        Transaction tx=null;  
        try{  
            tx=session.beginTransaction();  
            session.save(user);  
            tx.commit();  
        } catch (Exception e) {  
            tx.rollback();  
            throw new RuntimeException(e);  
            } finally{  
                session.close();  
            }  
    }  
    /** 
     * ɾ 
     * @param user 
     */  
    public void delete(int username){  
    	Session session=HibernateSessionFactory.getSession();
        Transaction tx=null;  
        try{  
            tx=session.beginTransaction();  
            session.delete(session.get(User.class, username));  
            tx.commit();  
        } catch (Exception e) {  
            tx.rollback();  
            throw new RuntimeException(e);  
            } finally{  
                session.close();  
            }  
    }  
    /** 
     * �� 
     * @param user 
     */  
    public void update(User user){  
    	Session session=HibernateSessionFactory.getSession(); 
        Transaction tx=null;  
        try{  
            tx=session.beginTransaction();  
            session.update(user);  
            tx.commit();  
        } catch (Exception e) {  
            tx.rollback();  
            throw new RuntimeException(e);  
            } finally{  
                session.close();  
            }  
    }  
    /** 
     * �� 
     * @param id 
     */  
    public User getByUsername(String username){  
    	Session session=HibernateSessionFactory.getSession();
        Transaction tx=null;  
        try{  
            tx=session.beginTransaction();  
            User user=(User) session.get(User.class, username);  
            tx.commit();  
            return user;  
        } catch (Exception e) {  
            tx.rollback();  
            throw new RuntimeException(e);  
            } finally{  
                session.close();  
            }  
    }  
      
    public List<User> findAll(){  
    	Session session=HibernateSessionFactory.getSession();
        Transaction tx=null;  
        try{  
            tx=session.beginTransaction();  
            List<User> list=session.createQuery( //ʹ��HQL��ѯ  
                    "FROM User").list();//���������õ�list  
            tx.commit();  
            return list;  
        } catch (Exception e) {  
            tx.rollback();  
            throw new RuntimeException(e);  
            } finally{  
                session.close();  
            }  
          
    }  
      
    /** 
     * ��ҳ������һҳ�������б� 
     * @param firstResult �ӽ���б��е��Ǹ�������ʼȡ���� 
     * @param maxResults ���ȡ���������� 
     * @return  list+count���ص����� 
     */  
//    public QueryResult findAll(int firstResult, int maxResults){  
//    	Session session=HibernateSessionFactory.getSession();
//        Transaction tx=null;  
//        try{  
//            tx=session.beginTransaction();  
//            //��ѯһҳ�������б�  
//            //��ʽһ  
////          Query query=session.createQuery("FROM User");  
////          query.setFirstResult(firstResult);  
////          query.setMaxResults(maxResults);  
////          List<User> list=query.list();  
//            //��ʽ��  
//            List<User> list=session.createQuery("FROM User")  
//                    .setFirstResult(firstResult)  
//                    .setMaxResults(maxResults)  
//                    .list();  
//            //��ѯ�ܼ�¼��  
//            Long count=(Long)session.createQuery("SELECT COUNT(*) FROM User")  
//                    .uniqueResult();  
//            tx.commit();  
//            return new QueryResult(count.intValue(),list);  
//        } catch (Exception e) {  
//            tx.rollback();  
//            throw new RuntimeException(e);  
//            } finally{  
//                session.close();  
//            }  
//    }  

}
