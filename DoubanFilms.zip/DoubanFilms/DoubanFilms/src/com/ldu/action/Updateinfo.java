package com.ldu.action;

import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.ldu.model.*;
import com.opensymphony.xwork2.ActionSupport;

public class Updateinfo extends ActionSupport implements SessionAware {
	
	private Map<String, Object> mysession;
	private static SessionFactory factory;
	Transaction tx = null;
	User user;
	
	public String execute(){
		System.out.println("����������Ϣ�ˣ�");
		System.out.println("id:"+user.getId());

		System.out.println("username:"+user.getUsername());
		System.out.println("name:"+user.getName());
		System.out.println("pass:"+user.getPassword());

		System.out.println("sex:"+user.getSex());

		System.out.println("age:"+user.getAge());
		mysession.remove("username");
		mysession.put("username",user.getUsername());
		factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		try {
			Transaction tx = session.beginTransaction();
			session.update(user);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
		}
		
		return SUCCESS;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.mysession=session;
	}
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
}
