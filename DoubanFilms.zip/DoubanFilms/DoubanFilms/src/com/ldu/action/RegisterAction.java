package com.ldu.action;

import com.ldu.db.Userinfo;
import com.ldu.model.User;
import com.opensymphony.xwork2.ActionSupport;

public class RegisterAction extends ActionSupport{
	
	private static final long serialVersionUID = 1L;
	User user; /* model�� */
	private String username;
	private String password;
	private String password2;
	private String result ;
	
	public String execute() {
		System.out.println("����ע���ˣ�");
		this.setResult("{\"login\":\"false\"}");
		Userinfo ui=new Userinfo();
		user=new User();
		user.setUsername(username);
		user.setPassword(password);
		
		if(ui.register(user)){
			System.out.println("ע�᲻��ͻ��"+username);
			result = "{\"login\":\"success\"}";
		}
		return "success";
	}
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword2() {
		return password2;
	}
	public void setPassword2(String password2) {
		this.password2 = password2;
	}
}
