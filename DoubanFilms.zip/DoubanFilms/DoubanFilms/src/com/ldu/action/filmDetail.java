package com.ldu.action;

import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.ldu.model.Comments;
import com.ldu.model.Movies;
import com.ldu.model.Pagebean;
import com.opensymphony.xwork2.ActionSupport;

public class filmDetail extends ActionSupport implements SessionAware{
	//
	private static SessionFactory factory;
	//
	private Map<String, Object> mysession;
	private int filmindex;
	List <Movies> results;
	List<Comments> clist;
	Pagebean  pp=new Pagebean();
	//
	private static final long serialVersionUID = 1L;
	
	public String execute(){
		factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
	    
		try {
			System.out.println("�����鿴filmdetail ��");
			results = (List<Movies>)mysession.get("mlist");
			Movies mm=results.get(filmindex);
			System.out.println("moviename:"+mm.getName());
			
			Transaction tx = session.beginTransaction();
			Criteria cr = session.createCriteria(Comments.class);
			cr.add(Restrictions.eq("rank", mm.getRank()));
			clist = cr.list();
			tx.commit();
			mysession.remove("clist");
			mysession.put("clist", clist);
			mysession.put("filmindex", filmindex);
			System.out.println("list size ��С:"+clist.size());
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
		} finally {
			session.close();
			factory.close();
		}
		return SUCCESS;
	}
	
	public List<Comments> getClist() {
		return clist;
	}

	public void setClist(List<Comments> clist) {
		this.clist = clist;
	}

	public Pagebean getPp() {
		return pp;
	}

	public void setPp(Pagebean pp) {
		this.pp = pp;
	}

	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.mysession=session;
	}

	public int getFilmindex() {
		return filmindex;
	}

	public void setFilmindex(int filmindex) {
		this.filmindex = filmindex;
	}
	
	
}
