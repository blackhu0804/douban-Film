package com.ldu.action;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;
import org.apache.struts2.interceptor.SessionAware;
import com.ldu.db.dbconnect;
import com.ldu.model.User;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class UserInfoAction extends ActionSupport implements SessionAware{
	private User user;
	private Map session;
	
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	public String Look_UserInfo() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		String sql="select * from users";
		ResultSet rs=dbconn.select(sql);
		ArrayList<User> list = new ArrayList();			
		while(rs.next()) { 
			User us = new User();
			us.setId(rs.getInt("id"));
			us.setUsername(rs.getString("username"));
			us.setName(rs.getString("name"));
			us.setSex(rs.getString("sex"));
			us.setAge(rs.getInt("age"));
			list.add(us);
		}
		session.put("us", list);
		return "LookInfo_success";
	}
	
	public String DeleteUser() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		String sql1="delete from users where id = '"+user.getId()+"' "; 
		dbconn.delete(sql1);
		System.out.println("ɾ���û��ɹ�����");
		//���²���һ��session
		String sql2="select * from users";
		ResultSet rs2=dbconn.select(sql2);
		ArrayList<User> list = new ArrayList();			
		while(rs2.next()) { 
			User us1 = new User();
			us1.setId(rs2.getInt("id"));
			us1.setUsername(rs2.getString("username"));
			us1.setName(rs2.getString("name"));
			us1.setSex(rs2.getString("sex"));
			us1.setAge(rs2.getInt("age"));
			list.add(us1);
		}
		session.put("us", list);
		return "Delete_User_success";
	}

}
