package com.ldu.action;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.ldu.getsession.HibernateSessionFactory;
import com.ldu.model.Collections;
import com.ldu.model.Comments;
import com.ldu.model.User;
import com.opensymphony.xwork2.ActionSupport;

public class InfoAction extends ActionSupport implements SessionAware{
	private static SessionFactory factory;
	Transaction tx = null;
	private Map<String, Object> mysession;
	List ulist;
	User user;
	String username;
	
	public String execute(){
		factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		username=(String)mysession.get("username");
		
		Transaction tx = session.beginTransaction();
		Criteria cr = session.createCriteria(User.class);
		cr.add(Restrictions.eq("username", username));
		ulist=cr.list();
		tx.commit();
		user=(User)ulist.get(0);
		
		System.out.println("id:"+user.getId());

		System.out.println("username:"+user.getUsername());
		System.out.println("name:"+user.getName());
		System.out.println("pass:"+user.getPassword());

		System.out.println("sex:"+user.getSex());

		System.out.println("age:"+user.getAge());
		
		mysession.put("user",user);
		
		
		return SUCCESS;
	}
	
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.mysession=session;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
}
