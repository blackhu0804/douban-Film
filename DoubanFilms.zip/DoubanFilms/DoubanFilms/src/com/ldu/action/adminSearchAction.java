package com.ldu.action;

import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import com.ldu.getsession.HibernateSessionFactory;
import com.ldu.model.Movies;
import com.opensymphony.xwork2.ActionSupport;

public class adminSearchAction extends ActionSupport implements SessionAware{
	Session session = HibernateSessionFactory.getSession();
	Transaction tx = null;
	private Map<String, Object> mysession;
	String key;
	String result;
	
	public String execute() {
		System.out.println("key值传入成功"+key);
		Criteria cr = session.createCriteria(Movies.class);
		List list;
		
		Disjunction dis=Restrictions.disjunction();
		dis.add(Restrictions.ilike("category", "%"+key+"%" ,MatchMode.ANYWHERE));
		dis.add(Restrictions.ilike("actor", "%"+key+"%" ,MatchMode.ANYWHERE));
		dis.add(Restrictions.ilike("name", "%"+key+"%" ,MatchMode.ANYWHERE));
		dis.add(Restrictions.ilike("year", "%"+key+"%" ,MatchMode.ANYWHERE));
		cr.add(dis);
		
		list=cr.list();
		System.out.println("list��С:"+list.size());
		mysession.put("adminlist", list);
		result = "{\"login\":\"success\"}";
		return "search_success";
	}
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.mysession=session;
	}
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
}
