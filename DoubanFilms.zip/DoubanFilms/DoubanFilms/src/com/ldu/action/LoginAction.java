package com.ldu.action;

import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ldu.db.Userinfo;
import com.ldu.db.dbconnect;
import com.ldu.model.Admin;
import com.ldu.model.User;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport implements SessionAware {

	private static final long serialVersionUID = 1L;
	User user; /* model�� */
	private String result ;
	private Admin admin ;
	private Map<String, Object> mysession;
	
	public String execute() {
		System.out.println("������¼�ˣ�");
		Userinfo UI=new Userinfo();
		List list=UI.login(user);
		this.setResult("{\"login\":\"false\"}");
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			User u = (User) iterator.next();
			if(u.getPassword().equals(user.getPassword())){
				System.out.println("��¼�ɹ��û�����"+user.getUsername());
				mysession.put("username", user.getUsername());
				result = "{\"login\":\"success\"}";
			}
		}
		return "success";
	}
	public String adminLogin() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		String sql="select * from admin";
		ResultSet rs=dbconn.select(sql);
		if(rs.next())
		{
			if(admin.getUsername().equals(rs.getString("username")) && admin.getPassword().equals(rs.getString("password")))
			{
				return "Success";
			}
			else
				return "fail";
		}
		else
			return "fail";
	}
	
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.mysession=session;
	}
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
}
