package com.ldu.action;

import java.util.List;
import java.util.Map;

import javax.enterprise.inject.New;

import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ldu.getsession.HibernateSessionFactory;
import com.ldu.model.Movies;
import com.ldu.model.Pagebean;
import com.opensymphony.xwork2.ActionSupport;

public class Main extends ActionSupport implements SessionAware{
	
	private static final long serialVersionUID = 1L;
	Session session = HibernateSessionFactory.getSession();
	Transaction tx = null;
	
	List <Movies> results;
	Pagebean pp=new Pagebean();
	int pageindex;
	private Map<String, Object> mysession;
	
	public String execute(){
		System.out.println("��������ҳ���ˣ�");
		Criteria cr = session.createCriteria(Movies.class);
		results = cr.list();
		mysession.put("mlist", results);
//		System.out.println(pageindex);
//		cr.setFirstResult(1+(pageindex-1)*10);
//		cr.setMaxResults(10);
//		pp.setResults(cr.list());
//		pp.setString("����ҳ����"+pageindex);
//		pp.setPageindex(pageindex+1);
		return SUCCESS;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.mysession=session;
	}
	
	
	
	public int getPageindex() {
		return pageindex;
	}
	public void setPageindex(int pageindex) {
		this.pageindex = pageindex;
	}
	public Pagebean getPp() {
		return pp;
	}
	public void setPp(Pagebean pp) {
		this.pp = pp;
	}
	public List<Movies> getResults() {
		return results;
	}

	public void setResults(List<Movies> results) {
		this.results = results;
	}
	
}
