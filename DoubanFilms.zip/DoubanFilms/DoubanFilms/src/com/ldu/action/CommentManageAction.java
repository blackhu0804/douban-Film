package com.ldu.action;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.ldu.db.dbconnect;
import com.ldu.model.Comments;
import com.ldu.model.User;
import com.opensymphony.xwork2.ActionSupport;

public class CommentManageAction extends ActionSupport implements SessionAware{
	private User user; 
	private Comments comments;
	public Comments getComments() {
		return comments;
	}

	public void setComments(Comments comments) {
		this.comments = comments;
	}

	private Map session;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	
	public String CommentManage() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		String sql="select * from comments";
		ResultSet rs=dbconn.select(sql);
		ArrayList<Comments> list = new ArrayList();			
		while(rs.next()) { 
			Comments comm = new Comments();
			//int Rank=rs.getInt("rank");
//			String sql1="select name from movies where rank='"+Rank+"'";
//			ResultSet rs1=dbconn.select(sql1);
//			if(rs1.next())
//			{
//				comm.setMoviesName(rs1.getString("name"));
//			}
			comm.setRank(rs.getInt("rank"));
			comm.setCommentsId(rs.getInt("comments_id"));
			comm.setDetail(rs.getString("detail"));
			comm.setTime(rs.getTimestamp("time"));
			comm.setUsername(rs.getString("username"));
			comm.setApproveNum(rs.getString("approve_num"));
			list.add(comm);
		}
		session.put("comm", list);
		return "Look_Comment_success";
	}
	
	public String DeleteComment() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		
		String sql1="delete from comments where comments_id = '"+comments.getCommentsId()+"' "; 
		dbconn.delete(sql1);
		System.out.println("删除评论成功！！！");
		
		String sql2="select * from comments";
		ResultSet rs=dbconn.select(sql2);
		ArrayList<Comments> list = new ArrayList();			
		while(rs.next()) { 
			Comments comm = new Comments();
//			int Rank=rs.getInt("rank");
//			String sql3="select name from movies where rank='"+Rank+"'";
//			ResultSet rs1=dbconn.select(sql3);
//			if(rs1.next())
//			{
//				comm.setMoviesName(rs1.getString("name"));
//			}
			comm.setRank(rs.getInt("rank"));
			comm.setCommentsId(rs.getInt("comments_id"));
			comm.setDetail(rs.getString("detail"));
			comm.setTime(rs.getTimestamp("time"));
			comm.setUsername(rs.getString("username"));
			comm.setApproveNum(rs.getString("approve_num"));
			list.add(comm);
		}
		session.put("us", list);
		return "DeleteComment_success";
	}

}
