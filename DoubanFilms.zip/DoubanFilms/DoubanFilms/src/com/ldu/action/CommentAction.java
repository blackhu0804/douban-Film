package com.ldu.action;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.enterprise.inject.New;
import javax.print.attribute.standard.DateTimeAtCompleted;

import org.apache.struts2.interceptor.SessionAware;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ldu.getsession.HibernateSessionFactory;
import com.ldu.model.Comments;
import com.ldu.model.Pagebean;
import com.opensymphony.xwork2.ActionSupport;

public class CommentAction extends ActionSupport implements SessionAware {
	//
	private static SessionFactory factory; 
	Transaction tx = null;
	//

	private static final long serialVersionUID = 1L;
	
	Comments coms;
	String rank;
	String score;
	private Map<String, Object> mysession;
	private String result="{\"false\"}";
	List<Comments> list;
	Pagebean  pp=new Pagebean();

	private String username;
	
	public String execute() {
		factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
	    //
		System.out.println("过来写评论了！");
		username = (String)mysession.get("username"); 
		if(username!=null && username.length()!=0){
			coms.setRank(Integer.parseInt(rank));
			coms.setUsername(username);
			coms.setTime(new Timestamp(new Date().getTime()));
			coms.setApproveNum(score);
			String content=coms.getDetail();
			coms.setDetail(replace(content));
			try {
				tx = session.beginTransaction();
				session.save(coms);
				tx.commit();
				result = "{\"success\"}";
			} catch (Throwable ex) {
				System.err.println("Failed to create sessionFactory object." + ex);
			} finally {
				session.close();
				factory.close();
			}
		}
		
		return SUCCESS;
	}
	
	public String replace(String str){
		String [] mingan={"习近平","毛泽东","胡天浩","胡金磊","张家旺"};
		String result=str;
		if(result.contains("垃圾"))
			result=result.replaceAll("垃圾", "优秀");
		if(result.contains("fuck"))
			result=result.replaceAll("fuck", "like");
		for(int i=0;i<mingan.length;i++){
			if(result.contains(mingan[i])){
				result=result.replaceAll(mingan[i], "***");
			}
		}
		return result;
	}
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public Comments getComs() {
		return coms;
	}

	public void setComs(Comments coms) {
		this.coms = coms;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.mysession = session;
	}
}
