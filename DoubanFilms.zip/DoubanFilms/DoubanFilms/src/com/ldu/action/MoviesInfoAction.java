package com.ldu.action;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;
import org.apache.struts2.interceptor.SessionAware;
import com.ldu.db.dbconnect;
import com.ldu.model.Movies;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class MoviesInfoAction extends ActionSupport implements SessionAware{
	private Movies movies;
	private Map session;
	public int set_rank;
	

	public int getSet_rank() {
		return set_rank;
	}

	public void setSet_rank(int set_rank) {
		this.set_rank = set_rank;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public Movies getMovies() {
		return movies;
	}

	public void setMovies(Movies movies) {
		this.movies = movies;
	}
	
	public String Look_MoviesInfo() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		String sql="select * from movies";
		ResultSet rs=dbconn.select(sql);
		ArrayList<Movies> list = new ArrayList();			
		while(rs.next()) { 
			Movies mov=new Movies();
			mov.setRank(rs.getInt("rank"));
			mov.setName(rs.getString("name"));
			mov.setScore(rs.getDouble("score"));
			mov.setQuote(rs.getString("quote"));
			mov.setActor(rs.getString("actor"));
			mov.setCategory(rs.getString("category"));
			mov.setYear(rs.getString("year"));
			mov.setCountry(rs.getString("country"));
			list.add(mov);
		}
		session.put("mov", list);
		return "Look_MoviesInfo_success";
	}
	
	public String Delete_Movies() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		String sql1="delete from movies where rank = '"+movies.getRank()+"' "; 
		dbconn.delete(sql1);
		System.out.println("删除电影信息");
		String sql2="select * from movies";
		ResultSet rs2=dbconn.select(sql2);
		ArrayList<Movies> list = new ArrayList();			
		while(rs2.next()) { 
			Movies mov1=new Movies();
			mov1.setRank(rs2.getInt("rank"));
			mov1.setName(rs2.getString("name"));
			mov1.setScore(rs2.getDouble("score"));
			mov1.setQuote(rs2.getString("quote"));
			mov1.setActor(rs2.getString("actor"));
			mov1.setCategory(rs2.getString("category"));
			mov1.setYear(rs2.getString("year"));
			mov1.setCountry(rs2.getString("country"));
			list.add(mov1);
		}
		session.put("mov", list);
		return "Delete_Movies_success";
	}
	//将单个选中的电影信息插入session
	public String Set_Movies() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		set_rank=movies.getRank();
		ActionContext.getContext().getSession().put("rank", set_rank);
		String sql3="select * from movies where rank='"+movies.getRank()+"' ";
		System.out.println("ssssssssssssssssss"+set_rank);
		ResultSet rs3=dbconn.select(sql3);
		if(rs3.next()) { 
			Movies mov2=new Movies();
			mov2.setRank(rs3.getInt("rank"));
			mov2.setName(rs3.getString("name"));
			mov2.setScore(rs3.getDouble("score"));
			mov2.setQuote(rs3.getString("quote"));
			mov2.setActor(rs3.getString("actor"));
			mov2.setCategory(rs3.getString("category"));
			mov2.setYear(rs3.getString("year"));
			mov2.setCountry(rs3.getString("country"));
			session.put("someone_mov", mov2);
		}
		return "Set_Movies_success";
	}
	//更新选中电影信息
	public String moviesUpdate() throws Exception
	{
		System.out.println("wwwwwwwwwwwwwwwww"+movies.getRank());
		dbconnect dbconn=new dbconnect();
		double SCORE=movies.getScore();
		String sql="update movies set name='"+movies.getName()+"',score='"+SCORE+"',quote='"+movies.getQuote()+"',actor='"+movies.getActor()+"',category='"+movies.getCategory()+"',year='"+movies.getYear()+"',country='"+movies.getCountry()+"' where rank='"+movies.getRank()+"' ";
		dbconn.update(sql);
		System.out.println("修改电影信息成功！");
		String sql1="select * from movies";
		ResultSet rs=dbconn.select(sql1);
		ArrayList<Movies> list1 = new ArrayList();	
		while(rs.next()) { 
			Movies mov3=new Movies();
			mov3.setRank(rs.getInt("rank"));
			mov3.setName(rs.getString("name"));
			mov3.setScore(rs.getDouble("score"));
			mov3.setQuote(rs.getString("quote"));
			mov3.setActor(rs.getString("actor"));
			mov3.setCategory(rs.getString("category"));
			mov3.setYear(rs.getString("year"));
			mov3.setCountry(rs.getString("country"));
			list1.add(mov3);
		}
		session.put("mov", list1);
		System.out.println("成功再次插入session！！！！！！！！！！！！！");
		return "UpdateMoviesSuccess";
	}
	
	public String Upload_Movies() throws Exception
	{
		dbconnect dbconn=new dbconnect();
		String getRows="select * from movies";
		ResultSet rs=dbconn.select(getRows);
		rs.last();
		int rows=rs.getRow()+1;
		double score=movies.getScore();
		String sql="insert into movies values('"+rows+"','"+movies.getName()+"','"+score+"','https://img3.doubanio.com/view/photo/s_ratio_poster/public/p532195562.webp','"+movies.getQuote()+"','"+movies.getActor()+"','"+movies.getCategory()+"','"+movies.getYear()+"','"+movies.getCountry()+"')";
		dbconn.insert(sql);
		return "Upload_Movies_success";
	}
}
