package com.ldu.model;

import java.util.List;

public class Pagebean {
	
	List <Movies> results;
	public List <Comments> clist;
	
	String string;
	
	int pageindex;
	
	public List<Comments> getClist() {
		return clist;
	}

	public void setClist(List<Comments> clist) {
		this.clist = clist;
	}

	public String getString() {
		return string;
	}

	public void setString(String string) {
		this.string = string;
	}

	public List<Movies> getResults() {
		return results;
	}

	public void setResults(List<Movies> results) {
		this.results = results;
	}

	public int getPageindex() {
		return pageindex;
	}

	public void setPageindex(int pageindex) {
		this.pageindex = pageindex;
	}
	
}
