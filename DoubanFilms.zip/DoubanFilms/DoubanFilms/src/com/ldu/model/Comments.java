package com.ldu.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Comments entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "comments", catalog = "douban")

public class Comments implements java.io.Serializable {

	// Fields

	private Integer commentsId;
	private Integer rank;
	private String detail;
	private String username;
	private Timestamp time;
	private String approveNum;


	// Constructors

	/** default constructor */
	public Comments() {
	}

	/** full constructor */
	public Comments(Integer commentsId, Integer rank, String detail, String username, Timestamp time,
			String approveNum) {
		this.commentsId = commentsId;
		this.rank = rank;
		this.detail = detail;
		this.username = username;
		this.time = time;
		this.approveNum = approveNum;
	}

	// Property accessors
	@Id

	@Column(name = "comments_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getCommentsId() {
		return this.commentsId;
	}

	public void setCommentsId(Integer commentsId) {
		this.commentsId = commentsId;
	}

	@Column(name = "rank", nullable = false)

	public Integer getRank() {
		return this.rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	@Column(name = "detail", nullable = false)

	public String getDetail() {
		return this.detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	@Column(name = "username", nullable = false)

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(name = "time", nullable = false, length = 19)

	public Timestamp getTime() {
		return this.time;
	}

	public void setTime(Timestamp time) {
		this.time = time;
	}

	@Column(name = "approve_num", nullable = false)

	public String getApproveNum() {
		return this.approveNum;
	}

	public void setApproveNum(String approveNum) {
		this.approveNum = approveNum;
	}

}