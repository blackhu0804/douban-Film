package com.ldu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Collections entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "collections", catalog = "douban")

public class Collections implements java.io.Serializable {

	// Fields

	private Integer id;
	private String username;
	private Integer rank;

	// Constructors

	/** default constructor */
	public Collections() {
	}

	/** full constructor */
	public Collections(Integer id, String username, Integer rank) {
		this.id = id;
		this.username = username;
		this.rank = rank;
	}

	// Property accessors
	@Id

	@Column(name = "id", unique = true, nullable = false)

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "username", nullable = false)

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(name = "rank", nullable = false)

	public Integer getRank() {
		return this.rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

}