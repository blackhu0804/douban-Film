package com.ldu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Movies entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "movies", catalog = "douban")

public class Movies implements java.io.Serializable {

	// Fields

	private Integer rank;
	private String name;
	private Double score;
	private String imgUrl;
	private String quote;
	private String actor;
	private String category;
	private String year;
	private String country;

	// Constructors

	/** default constructor */
	public Movies() {
	}

	/** full constructor */
	public Movies(String name, Double score, String imgUrl, String quote, String actor, String category, String year,
			String country) {
		this.name = name;
		this.score = score;
		this.imgUrl = imgUrl;
		this.quote = quote;
		this.actor = actor;
		this.category = category;
		this.year = year;
		this.country = country;
	}

	// Property accessors
	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "rank", unique = true, nullable = false)

	public Integer getRank() {
		return this.rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	@Column(name = "name")

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "score", precision = 20, scale = 1)

	public Double getScore() {
		return this.score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

	@Column(name = "imgUrl")

	public String getImgUrl() {
		return this.imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	@Column(name = "quote")

	public String getQuote() {
		return this.quote;
	}

	public void setQuote(String quote) {
		this.quote = quote;
	}

	@Column(name = "actor")

	public String getActor() {
		return this.actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}

	@Column(name = "category")

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Column(name = "year")

	public String getYear() {
		return this.year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@Column(name = "country")

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}